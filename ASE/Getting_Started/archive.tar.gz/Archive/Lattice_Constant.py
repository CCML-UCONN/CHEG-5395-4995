
from espresso import espresso

from ase.io import read, write

import numpy as np

slab = read('Ti2C.traj')

strains = np.linspace(0.9, 1.1, 10) # This creates a vector that ranges from 0.9 to 1.1 in 8 equal increments (10 total points, 2 endpoints)

calc = espresso(pw=700,             #plane-wave cutoff
                dw=7000,                    #density cutoff
                xc='BEEF-vdW',          #exchange-correlation functional
                kpts=(8,8,1),	#k-point sampling;
                nbands=-20,             #20 extra bands besides the bands needed to hold
                #the valence electrons
                sigma=0.1,
                convergence= {'energy':1e-6,
                'mixing':0.1,
                'nmix':10,
                'mix':4,
                'maxsteps':500,
                'diag':'david'
                },	#convergence parameters
                output={'removesave':True},
                dipole={'status':False}, #dipole correction to account for periodicity in z
                spinpol=False,
                outdir='calcdir')	#output directory for Quantum Espresso files

A = slab.get_cell()

a = 3.1 # This is the lattice constant we are starting from

for i in strains: # The indented blocks are a loop; this does the same calculation for lattice constants at differnt strain, set by the strain vector above.
	A[0][0] = a*i
	A[1][0] = -0.5*a*i
	A[1][1] = np.sqrt(3)*0.5*a*i # This defines the lattice from a given lattice constant. This will be the same for every MXene you study.

	slab.set_cell(A) # Assign the new lattice constants to your cell

	slab.set_calculator(calc)

	energy  = slab.get_potential_energy()

	print "The energy of the system with lattice constant %s is %.3f eV" % (a*i, energy)
