
from espresso import espresso

from ase.io import read, write

slab = read('Ti2C.traj')

calc = espresso(pw=700,             #plane-wave cutoff
                dw=7000,                    #density cutoff
                xc='BEEF-vdW',          #exchange-correlation functional
                kpts=(8,8,1),	#k-point sampling;
                nbands=-20,             #20 extra bands besides the bands needed to hold
                #the valence electrons
                sigma=0.1,
                convergence= {'energy':1e-6,
                'mixing':0.1,
                'nmix':10,
                'mix':4,
                'maxsteps':500,
                'diag':'david'
                },	#convergence parameters
                output={'removesave':True},
                dipole={'status':False}, #dipole correction to account for periodicity in z
                spinpol=False,
                outdir='calcdir')	#output directory for Quantum Espresso files

slab.set_calculator(calc)
energy  = slab.get_potential_energy()

print "The energy of the system is %.3f eV" % energy
