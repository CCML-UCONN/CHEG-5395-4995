

from espresso import espresso

from ase.io import read

Mo2C = read('Ti2C.traj')

from ase.optimize import BFGS

calc = espresso(pw=700,             #plane-wave cutoff
                dw=7000,                    #density cutoff
                xc='BEEF-vdW',          #exchange-correlation functional
                kpts=(4,4, 1),	#k-point sampling;
                nbands=-100,             #20 extra bands besides the bands needed to hold
                #the valence electrons
                sigma=0.1,
                convergence= {'energy':1e-6,
                'mixing':0.1,
                'nmix':10,
                'mix':4,
                'maxsteps':500,
                'diag':'david'
                },	#convergence parameters
                dipole={'status':True}, #dipole correction to account for periodicity in z
                spinpol=False,
                output={'removesave':True},
                outdir='calcdir')	#output directory for Quantum Espresso files


Mo2C.set_calculator(calc)

dyn = BFGS(Mo2C, trajectory='Relax.traj',logfile='opt.log') # This saves each atomic step in the Relax.traj file
dyn.run(fmax=0.05) # Relax the atoms until you reach a maximum of 0.05 eV/angstrom
