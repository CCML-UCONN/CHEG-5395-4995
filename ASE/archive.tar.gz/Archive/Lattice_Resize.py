from ase.io import read, write
import numpy as np

slab = read('Ti2C.traj')

A = slab.get_cell()

a = 3.1 # This is the lattice constant we want to resize the cell; change this to the value you want

A[0][0] = a
A[1][0] = -0.5*a
A[1][1] = np.sqrt(3)*0.5*a # This defines the lattice from a given lattice constant. This will be the same for every MXene you study.

slab.set_cell(A)

write('Ti2C.traj', slab)
